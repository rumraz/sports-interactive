import axios from "axios";
import React, { useEffect, useState } from "react";
import './App.scss'

function App() {
  const [playerList, setPlayerList] = useState(0);
  const [searchInput, setSearchInput] = useState("");
  const [filteredResults, setFilteredResults] = useState([]);
  
  const getData = async () => {
    const { data } = await axios("https://api.npoint.io/20c1afef1661881ddc9c");
    setPlayerList(data.playerList);
  };

  useEffect(() => {
    getData();
  }, [])

  console.log(playerList);

  const searchItems = (e) => {
    let searchValue = e.target.value;
    setSearchInput(searchValue)
    if (searchInput !== "") {
      const filteredData = playerList.filter((item) => {
        return (
          item.TName.toUpperCase().search(searchValue.toUpperCase()) >= 0 ||
          item.PFName.toUpperCase().search(searchValue.toUpperCase()) >= 0          
        )
      })
      setFilteredResults(filteredData);
    }
    else {
      setPlayerList(playerList);
    }
  }
  return (
    <>
      <div class="container">
        <div className="search">
          <form class="search-container">
            <input type="text" id="search-bar" onChange={searchItems} placeholder="What can I help you with today?" />
            <a href="#"><img class="search-icon" src="http://www.endlessicons.com/wp-content/uploads/2012/12/search-icon.png" /></a>
          </form>
        </div>
        <div class="card__wrap--outer">
          {searchInput.length > 1 ? (
             filteredResults.sort((a,b)=> a.Value - b.Value).map((item) => {
              return (
                <div class="card__wrap--inner">
                  <div className="card">
                    <img src={process.env.PUBLIC_URL + '/player-images/' + item.Id + `.jpg`} />
                    <div class="card__item">
                      <h2>{item.PFName}</h2>
                      <small>{item.SkillDesc}</small>
                    </div>
                    <div class="card__sub">
                      <h6>Value: {item.Value}</h6>
                    </div>
                    <div class="card__item flexible">
                      <h5>Upcoming Matches:   <small>{item.UpComingMatchesList[0].CCode} <b>Vs</b> {item.UpComingMatchesList[0].VsCCode}</small>  </h5>
                    </div>
                  </div>
                </div>
              )
            })
          ) : (
            playerList && playerList.sort((a,b)=> a.Value - b.Value).map((item) => {
              return (
                <div class="card__wrap--inner">
                  <div className="card">
                    <img src={process.env.PUBLIC_URL + '/player-images/' + item.Id + `.jpg`} />
                    <div class="card__item">
                      <h2>{item.PDName}</h2>
                      <small>{item.SkillDesc}</small>
                    </div>
                    <div class="card__sub">
                      <h6>Value: {item.Value}</h6>
                    </div>
                    <div class="card__item flexible">
                      <h5>Upcoming Matches:   <small>{item.UpComingMatchesList[0].CCode} <b>Vs</b> {item.UpComingMatchesList[0].VsCCode}</small>  </h5>
                    </div>
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>
    </>
  );
}

export default App;